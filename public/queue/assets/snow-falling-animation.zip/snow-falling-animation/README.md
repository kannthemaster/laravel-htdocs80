![](https://github.com/Golt1on/snow-effect/blob/main/snow.gif)
